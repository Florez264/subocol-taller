# Subocol — ejecución y entrega

Solución de la prueba técnica: Angular, dos microservicios Java 21/Spring Boot y MySQL 8.4. Esta carpeta no es otro microservicio: reúne los archivos que permiten levantar y revisar la solución completa.

## Aplicación y repositorios

- [Aplicación desplegada](https://subocol-taller.vercel.app/acceso)
- [Frontend Angular](https://github.com/Florez264/subocol-taller)
- [Microservicio Órdenes](https://github.com/Florez264/ordenes-service)
- [Microservicio Agenda](https://github.com/Florez264/agenda-service)

Esta carpeta está incluida, sin secretos, en `entrega/subocol-infra.zip` del repositorio del frontend. El diagrama y DECISIONES.md también están visibles directamente en ese repositorio. No es obligatorio crear un cuarto repositorio: el PDF pide el código, diagrama, decisiones y ejecución con Compose; no exige un servicio adicional de infraestructura.

## Clonar con la estructura esperada

Desde una carpeta vacía:

```sh
git clone https://github.com/Florez264/ordenes-service.git ordenes-service
git clone https://github.com/Florez264/agenda-service.git agenda-service
git clone https://github.com/Florez264/subocol-taller.git frontend
```

Extraer el paquete desde la carpeta donde se clonaron los tres repositorios. En PowerShell:

```powershell
Expand-Archive -LiteralPath .\frontend\entrega\subocol-infra.zip -DestinationPath .
```

En Linux/macOS:

```sh
unzip frontend/entrega/subocol-infra.zip
```

Así `subocol-infra` queda al mismo nivel. El nombre local `frontend` importa porque Compose usa `../frontend` como contexto de construcción; no se debe colocar un repositorio dentro de otro.

```text
entrega/
  ordenes-service/
  agenda-service/
  frontend/
  subocol-infra/
    compose.yaml
    CONTEXTO.md
    DECISIONES.md
    database/init/
```

## Arrancar todo con Docker Compose

Requisitos: Docker Engine/Desktop con contenedores Linux y Docker Compose v2, acceso a Internet para descargar imágenes/dependencias y puertos 4200, 8081, 8082 y 3308 libres. No hace falta instalar Java, Maven, Node ni Angular en el equipo del evaluador.

Desde `subocol-infra`:

```sh
docker compose up
```

La primera ejecución construye las imágenes que falten. Para reconstruir después de cambios de código:

```sh
docker compose up --build
```

Esperar el arranque de MySQL y de las dos APIs. Abrir **http://localhost:4200/acceso**.

Credenciales exclusivamente locales de demostración:

- Usuario `asesor`, contraseña `asesor-local-password`.
- Segundo usuario `asesor2`, contraseña `asesor2-local-password`.

No son las credenciales cloud. El frontend Docker usa localhost:8081 y localhost:8082; no utiliza Railway. Vercel conserva sus URLs de producción. Se valida el acceso desde el navegador de la máquina Docker; para otros dominios o equipos hay que ajustar URLs y CORS explícitamente.

| Componente | Dirección local | Función |
|---|---|---|
| Angular/Nginx | http://localhost:4200 | SPA y rutas directas |
| Órdenes | http://localhost:8081 | Órdenes, estado, historial y buzón de cierres |
| Agenda | http://localhost:8082 | Franjas, citas, cancelaciones y avisos |
| MySQL | localhost:3308 | Dos bases independientes, acceso administrativo local |

Salud: `http://localhost:8081/actuator/health` y `http://localhost:8082/actuator/health`. La colección [Postman](Subocol.postman_collection.json) sirve para consumir las APIs locales; las operaciones también están disponibles en Angular.

Para detener y conservar datos:

```sh
docker compose stop
```

El proyecto se llama `subocol` y conserva el volumen `subocol_mysql_data`. No ejecutar `down -v` sobre una instalación con datos que se quieran conservar. Los scripts de inicialización solo se ejecutan al crear un volumen vacío; Flyway aplica después las migraciones propias de cada servicio.

## Alcance funcional

- Crear órdenes con cliente, vehículo, aseguradora opcional y descripción.
- Listar/consultar órdenes, avanzar por estados y reabrir con motivo y versión esperada.
- Historial con actor autenticado, fecha y motivo, protegido en Java, permisos y triggers MySQL.
- Franjas por asesor, cupos, citas de INGRESO y ENTREGA y cancelación manual con motivo.
- Notificaciones de agendamiento/cancelación manual mediante outbox; LOG por defecto o Meta opcional.
- Cierre automático: Órdenes guarda un evento y Agenda cancela las reservas anteriores al cierre sin encolar un aviso de cancelación, libera cupos y confirma el evento. La sincronización es eventual; normalmente se observa tras el intervalo de 15 segundos y puede demorarse si hay caídas.
- Angular con NgRx, validaciones, paginación, filtros automáticos de franjas, tema claro/oscuro y diseño adaptable.

## Estados y prueba del cierre

REGISTRADA → EN_DIAGNOSTICO → EN_REPARACION → REPARADA → CERRADA. Desde diagnóstico también se puede pasar por PENDIENTE_AUTORIZACION. Reabrir una CERRADA devuelve EN_DIAGNOSTICO y exige motivo.

Para comprobar el cierre: crear una orden, avanzar hasta REPARADA, crear una franja futura y agendar ENTREGA. Cerrar la orden, esperar la sincronización y actualizar Agenda. La cita debe quedar CANCELADA por `sistema-cierre`, el cupo debe recuperarse y no debe aparecer un nuevo evento de cancelación. Reabrir no reactiva citas anteriores. Ver [evidencia real](PRUEBA_CIERRE.md).

## Persistencia, seguridad y configuración

Órdenes posee `ordenes_db`; Agenda posee `agenda_db`. Cada una tiene cuenta de aplicación con SELECT/INSERT/UPDATE y cuenta de migración propia. Los triggers impiden alterar el historial, pero un administrador con DDL puede retirarlos. No se promete inmutabilidad frente al dueño de la base.

Compose define valores locales conocidos y usa LOG sin secretos de Meta. Para pruebas privadas opcionales se puede usar `docker compose --env-file .env.local up --build`; no publicar ese archivo y no usar esa opción con credenciales de nube para la evaluación local. `.env.local.example` es una plantilla pública.

En Java el perfil local toma valores locales y el perfil cloud requiere variables externas de conexión y credenciales. Los archivos `environment*.ts` de Angular son públicos al compilar; nunca contienen tokens ni contraseñas. Las credenciales del asesor se mantienen solo en memoria del navegador. La preferencia visual del tema es lo único guardado en localStorage.

## Nube y despliegue continuo

Frontend en Vercel y dos servicios/MySQL en Railway. Los repositorios Java ejecutan pruebas, construyen imágenes y publican GHCR; Railway está conectado a sus ramas master y construye sus Dockerfile. Vercel importa el repositorio Angular. La infraestructura local no agrega consumo a Railway.

El origen estable `https://subocol-taller.vercel.app` está permitido en el perfil cloud mediante un valor configurable `FRONTEND_ORIGIN`, además de los orígenes de `CORS_ALLOWED_ORIGINS`. No se usa `*`, no se habilita CORS en `/internal/**` y las peticiones reales siguen autenticadas.

Para publicación no se incluyen credenciales cloud. Las credenciales de evaluación deben compartirse con el evaluador por el canal acordado. Ver [Railway](RAILWAY.md) para los detalles de despliegue y [decisiones](DECISIONES.md) para los límites del MVP.

## Documentos de entrega

- [Diagrama de contexto y propiedad de datos](CONTEXTO.md).
- [Fronteras, alternativas y dos propuestas de IA rechazadas](DECISIONES.md).
- [Pruebas y límites de la validación](VERIFICACION.md).
- [Cierre automático probado en Railway](PRUEBA_CIERRE.md).

La integración externa de aseguradoras, las plantillas finales de WhatsApp en español, el webhook de entrega, IAM completo y las pruebas de carga quedan fuera del alcance actual. El PDF permite simular WhatsApp mediante log y pide priorizar justificadamente.
