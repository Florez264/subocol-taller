# Despliegue de Subocol en Railway

Decision: un servidor MySQL con dos bases y cuatro usuarios. Los dos backends se despliegan como imagenes independientes ya publicadas en GHCR. No se usa la base de Franquicia ni se necesita Clever Cloud para este despliegue.

## 1. Proyecto y MySQL

Desde Railway crear un proyecto vacio llamado Subocol. Dentro: New > Database > MySQL. Mantener los dos backends y MySQL en el mismo entorno y region. Antes de inicializar el volumen preferir la imagen oficial mysql:8.4, que es la version probada localmente. Si el servicio ya inicializo una version mayor, NO cambiar a una version anterior sobre el mismo volumen; revisar version antes de seguir.

Conservar el volumen montado en `/var/lib/mysql` y la contrasena root generada por Railway. No copiar la clave root a los backends. Una replica, sin HA ni replicas de lectura para esta demostracion.

En Settings > Deploy > Custom Start Command de MySQL usar:

```text
docker-entrypoint.sh mysqld --innodb-use-native-aio=0 --disable-log-bin --performance_schema=0 --innodb-buffer-pool-size=128M --max-connections=20 --table-open-cache=256 --table-definition-cache=256 --tmp-table-size=16M --max-heap-table-size=16M
```

Es un punto inicial para pocas conexiones, no una garantia de RAM. El buffer de 128 MB no es el consumo total de MySQL. Comenzar con limite de 512 MB si el plan lo permite; revisar arranque y metricas antes de bajarlo. La plantilla puede tener un buffer por defecto de 1 GB: reemplazar ese valor, no agregar otra opcion contradictoria. Desactivar binlog en esta demostracion impide recuperacion a un instante mediante binlogs. Los datos persisten en el volumen; mantener copias si son necesarios.

## 2. Crear bases y usuarios

Usar la conexion de administrador proporcionada por Railway desde DBeaver (el usuario ya lo tiene) o cliente MySQL. Para conectar desde el equipo, habilitar temporalmente el TCP Proxy en Networking y usar el host y puerto PUBLICOS, no railway.internal. No publicar ni compartir la contrasena root. La conexion externa puede generar trafico facturable.

Copiar `database/railway/01-bootstrap.example.sql` a `01-bootstrap.private.sql` en la misma carpeta (ignorado por Git), sustituir los cuatro marcadores por claves distintas y ejecutar la copia en el MySQL NUEVO de Subocol. El script crea ordenes_db, agenda_db, usuarios de migracion con DDL y usuarios de aplicacion sin DELETE/DDL. No se debe ejecutar repetidamente como script de rotacion de claves. Si encuentra usuarios existentes se detiene esa sentencia; inspeccionar el resultado en vez de borrar bases. No usar el init local con contrasenas de desarrollo en la nube.

Al terminar se puede retirar el TCP Proxy si ya no se necesita acceso externo. Las APIs usan la red privada.

## 3. Backends

Agregar dos servicios desde Docker Image:

- Ordenes: `ghcr.io/florez264/ordenes-service:latest`, nombrar `ordenes-service`.
- Agenda: `ghcr.io/florez264/agenda-service:latest`, nombrar `agenda-service`.

Los paquetes GHCR deben ser publicos o configurar credenciales privadas de lectura en Railway. No crear ademas otro servicio desde GitHub para el mismo backend.

Cada repositorio tiene `.env.railway.example`: copiar sus valores al Raw Editor de Variables del servicio y sustituir los marcadores con las claves del bootstrap y credenciales de API nuevas. Confirmar el nombre del servicio MySQL y su dominio privado, no asumir que coincide si se renombro. `DB_USER` es usuario de aplicacion; `DB_MIGRATION_USER` el de migracion de esa misma base. API_USER/API_PASSWORD e INTERNAL_USER/INTERNAL_PASSWORD deben coincidir entre ambos servicios para facilitar el uso y la llamada interna.

Las URL de ejemplo usan el nombre de referencia `MySQL` para Railway y los puertos privados. `sslMode=PREFERRED` negocia TLS si esta disponible, pero no garantiza cifrado: esta opcion se limita al MySQL en la red privada del mismo proyecto. No usarla para una conexion publica; para acceso publico configurar TLS verificado y certificados. No convertir MYSQL_URL directamente en DB_URL: Java necesita una URL JDBC y la base propia, no la base railway del administrador.

Healthcheck `/actuator/health`, timeout 120 segundos, una replica, reinicio ON_FAILURE con 3 intentos y limite inicial 512 MB por API. No montar volumen a las APIs ni cambiar su comando de inicio. Desplegar primero Ordenes, luego Agenda. Flyway crea tablas y triggers automaticamente. La clave de migracion puede crear los triggers porque binlog esta deshabilitado en esta configuracion; no quitar V3 si ocurre un fallo.

Generar dominios publicos HTTPS para las APIs. CORS_ALLOWED_ORIGINS debe ser el dominio de Angular; local se puede probar con http://localhost:4200. Agenda consulta Ordenes por su dominio privado y puerto 8081. Empezar con LOG; despues cargar WHATSAPP en Agenda con variables privadas. El token local no se publica automaticamente ni se incluye en la imagen.

## 4. Verificar y controlar gasto

Comprobar salud de los dos servicios, autenticacion, crear orden, agendar cita y verificar el registro de notificacion. El cierre automatico de citas sigue pendiente: no presentarlo como terminado.

Configurar alertas y limite de gasto; revisar RAM, CPU y saldo tras el primer despliegue. Todos los servicios del workspace, incluido Franquicia si sigue encendido, pueden consumir saldo. No se garantiza una duracion del credito. Detener las APIs y MySQL al acabar la sustentacion si ya no hacen falta; los volumenes pueden seguir generando almacenamiento facturable aunque el proceso este detenido.

Agenda tiene un worker periodico; sus consultas a MySQL pueden impedir que Railway la suspenda. No apagar ese worker como medida de ahorro si se espera entrega/reintentos de notificaciones. Publicar nuevas imagenes en GHCR no despliega por si solo: configurar Image Auto Updates para latest o cambiar a una etiqueta SHA y desplegar manualmente.

Referencias: https://docs.railway.com/databases/mysql ; https://docs.railway.com/networking/private-networking ; https://docs.railway.com/pricing/cost-control .
