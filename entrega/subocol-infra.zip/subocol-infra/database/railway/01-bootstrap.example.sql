-- Ejecutar una vez como administrador SOLO en el MySQL nuevo de Subocol.
-- Sustituir cada marcador por una contrasena diferente antes de ejecutar.
-- No usar las claves locales ni subir el archivo con claves reales a Git.
CREATE DATABASE IF NOT EXISTS ordenes_db CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
CREATE DATABASE IF NOT EXISTS agenda_db CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
CREATE USER 'ordenes_migration'@'%' IDENTIFIED BY 'CAMBIAR_CLAVE_MIGRACION_ORDENES';
CREATE USER 'agenda_migration'@'%' IDENTIFIED BY 'CAMBIAR_CLAVE_MIGRACION_AGENDA';
CREATE USER 'ordenes_app'@'%' IDENTIFIED BY 'CAMBIAR_CLAVE_APP_ORDENES';
CREATE USER 'agenda_app'@'%' IDENTIFIED BY 'CAMBIAR_CLAVE_APP_AGENDA';
GRANT ALL PRIVILEGES ON ordenes_db.* TO 'ordenes_migration'@'%';
GRANT ALL PRIVILEGES ON agenda_db.* TO 'agenda_migration'@'%';
GRANT SELECT,INSERT,UPDATE ON ordenes_db.* TO 'ordenes_app'@'%';
GRANT SELECT,INSERT,UPDATE ON agenda_db.* TO 'agenda_app'@'%';
-- Las tablas y triggers los crea Flyway al desplegar los backends.
-- No hay DROP, TRUNCATE ni cambios sobre la base de Franquicia.
